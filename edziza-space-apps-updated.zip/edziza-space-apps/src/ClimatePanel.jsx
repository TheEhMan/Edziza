import React, { useEffect, useMemo, useState } from 'react';
import { WORLD_ORDER, WORLD_LABELS, WORLD_SITES, getSite, formatCoord } from './siteData.js';
import { PARAMETERS } from './parameters.js';

const MONTHS = [
  ['ANN', 'Annual average'], ['JAN', 'January'], ['FEB', 'February'], ['MAR', 'March'],
  ['APR', 'April'], ['MAY', 'May'], ['JUN', 'June'], ['JUL', 'July'],
  ['AUG', 'August'], ['SEP', 'September'], ['OCT', 'October'], ['NOV', 'November'], ['DEC', 'December']
];


const FACTS = {
  earth: { gravity: '9.80 m/s²', solarDay: '24.00 h', orbitalSolar: '1,361 W/m²' },
  mars: { gravity: '3.73 m/s²', solarDay: '24.66 h', orbitalSolar: '586 W/m²' },
  moon: { gravity: '1.62 m/s²', solarDay: '29.53 Earth days', orbitalSolar: '1,361 W/m²' }
};
const SOURCE_URLS = {
  nasaPower: 'https://power.larc.nasa.gov/docs/services/api/temporal/climatology/',
  mars: 'https://nssdc.gsfc.nasa.gov/planetary/factsheet/marsfact.html',
  moon: 'https://nssdc.gsfc.nasa.gov/planetary/factsheet/moonfact.html',
  earth: 'https://nssdc.gsfc.nasa.gov/planetary/factsheet/earthfact.html',
  lunarCoords: 'https://nssdc.gsfc.nasa.gov/planetary/lunar/lunar_sites.html'
};

function usePowerClimate(earthSite) {
  const [result, setResult] = useState({ status: 'loading', data: null, url: '' });
  const location = getSite('earth', earthSite);
  const url = useMemo(() => {
    const q = new URLSearchParams({
      parameters: 'T2M,RH2M,PS,WS10M,ALLSKY_SFC_SW_DWN',
      community: 'AG', longitude: String(location.lon), latitude: String(location.lat), format: 'JSON'
    });
    return `https://power.larc.nasa.gov/api/temporal/climatology/point?${q.toString()}`;
  }, [location.lon, location.lat]);

  useEffect(() => {
    const controller = new AbortController();
    setResult({ status: 'loading', data: null, url });
    fetch(url, { signal: controller.signal })
      .then(response => { if (!response.ok) throw new Error(`NASA POWER HTTP ${response.status}`); return response.json(); })
      .then(json => {
        const data = json?.properties?.parameter;
        if (!data?.T2M || !data?.RH2M) throw new Error('Unexpected NASA POWER response');
        setResult({ status: 'ready', data, url });
      })
      .catch(error => { if (error.name !== 'AbortError') setResult({ status: 'error', data: null, url }); });
    return () => controller.abort();
  }, [url]);
  return result;
}

function getMetric(id, world, location, power, month) {
  const site = location;
  const planet = FACTS[world];
  const cell = (value, status, note) => ({ value, status, note });
  const ref = (value, note = 'Planet-wide NASA reference; not a measurement at this location.') => cell(value, 'PLANET REF', note);
  const siteValue = (value, note) => cell(value, 'SITE CONTEXT', note);
  const missing = (note) => cell('Not available', 'NO LOCAL DATA', note);
  const earthPower = (key, unit, digits = 1) => {
    if (power.status !== 'ready') {
      return missing(power.status === 'error' ? 'NASA POWER request failed; no estimate is substituted.' : 'Waiting for NASA POWER climatology...');
    }
    const value = Number(power.data?.[key]?.[month]);
    if (!Number.isFinite(value) || value <= -990) return missing('No valid NASA POWER climatology cell was returned.');
    return cell(`${value.toFixed(digits)} ${unit}`, 'NASA POWER', 'Gridded climate average for these coordinates; not in-situ or real-time.');
  };
  switch (id) {
    case 'latitude': return siteValue(formatCoord(site.lat, 'lat'), 'Selected research/landmark coordinate.');
    case 'longitude': return siteValue(formatCoord(site.lon, 'lon'), 'Selected research/landmark coordinate.');
    case 'temperature': return world === 'earth' ? earthPower('T2M', '°C')
      : world === 'mars' ? ref('−59 °C', 'Mars-wide annual mean; NOT Hecates/Elysium/Albor air temperature.')
      : missing('The lunar surface changes drastically between sun and shade. No site/time-specific thermal model is supplied.');
    case 'pressure': return world === 'earth' ? earthPower('PS', 'kPa')
      : world === 'mars' ? ref('0.636 kPa', 'Approximate reference pressure at the Mars mean radius; highly variable with elevation/season.')
      : ref('Near vacuum', 'Moon has a very thin exosphere; nighttime reference about 3×10⁻¹⁵ bar.');
    case 'humidity': return world === 'earth' ? earthPower('RH2M', '%', 0)
      : world === 'mars' ? missing('No verified local relative humidity at any of these volcanic sites.')
      : cell('N/A', 'NO ATMOSPHERE', 'Humidity of a conventional atmosphere is not meaningful for the lunar exosphere.');
    case 'wind': return world === 'earth' ? earthPower('WS10M', 'm/s')
      : world === 'mars' ? missing('Viking rover site observations cannot be assigned to these three volcanoes.')
      : cell('N/A', 'NO ATMOSPHERE', 'No conventional atmospheric wind on the Moon.');
    case 'surfaceSolar': return world === 'earth' ? earthPower('ALLSKY_SFC_SW_DWN', 'kWh/m²/day', 2)
      : missing('No time/season/site-specific surface solar radiation model has been included.');
    case 'gravity': return ref(planet.gravity);
    case 'solarDay': return ref(planet.solarDay, 'Solar-day average; local light availability also depends on relief and latitude.');
    case 'orbitalSolar': return ref(planet.orbitalSolar, 'Mean top-of-atmosphere/orbital irradiance; NOT the energy at this surface site.');
    case 'terrain': return siteValue(site.terrain, 'Regional geologic classification; no new rock assay performed.');
    case 'ice': return siteValue(site.ice, 'Qualitative evidence summary; no site-specific ice volume or probability computed.');
    default: return missing('Unknown parameter.');
  }
}

function LocationSelector({ world, value, onChange }) {
  return <label className="data-location-select"><span>SELECT {world.toUpperCase()} LOCATION</span>
    <select value={value} onChange={event => onChange?.(world, event.target.value)}>
      {Object.values(WORLD_SITES[world]).map(location => <option key={location.id} value={location.id}>{location.label}</option>)}
    </select>
  </label>;
}

function DataWorld({ world, siteId, onSiteChange, power, month, compact }) {
  const location = getSite(world, siteId);
  const rows = compact ? PARAMETERS.filter(p => ['temperature', 'gravity', 'ice'].includes(p.id)) : PARAMETERS;
  return <article className={`parameter-world parameter-${world}`}>
    <header className="parameter-world-head">
      <span className={`planet-indicator ${world}`} />
      <div><span className="parameter-eyebrow">{WORLD_LABELS[world]}</span><h3>{location.label}</h3></div>
    </header>
    {!compact && <LocationSelector world={world} value={siteId} onChange={onSiteChange} />}
    <div className="parameter-rows">
      {rows.map(parameter => {
        const metric = getMetric(parameter.id, world, location, power, month);
        return <div key={parameter.id} className="parameter-row" title={parameter.detail}>
          <div className="parameter-row-title"><span className="parameter-counter">{String(PARAMETERS.indexOf(parameter) + 1).padStart(2, '0')}</span>
            <span>{parameter.label}</span></div>
          <strong>{metric.value}</strong>
          <span className={`parameter-status ${metric.status === 'NO LOCAL DATA' || metric.status === 'NO ATMOSPHERE' ? 'muted' : ''}`}>{metric.status}</span>
          {!compact && <p>{metric.note}</p>}
        </div>;
      })}
    </div>
    {!compact && <div className="parameter-world-foot"><p>{location.description}</p>
      <a href={location.evidence} target="_blank" rel="noreferrer">Study location reference</a></div>}
  </article>;
}

export default function ClimatePanel({ sites = { earth: 'snowshoe', mars: 'hecates', moon: 'apollo11' }, onSiteChange, compact = false, onOpenData }) {
  const [month, setMonth] = useState('ANN');
  const [focus, setFocus] = useState('all');
  const power = usePowerClimate(sites.earth);
  const worlds = compact || focus === 'all' ? WORLD_ORDER : [focus];
  return <section className={`climate-panel ${compact ? 'compact' : ''}`}>
    <header className="climate-header">
      <div><span className="eyebrow">03 WORLDS / 09 LOCATIONS / 12 PARAMETERS</span>
        <h2>{compact ? 'A quick environmental contrast' : 'Explore 12 scientific parameters'}</h2>
        <p>Compare places, but keep local measurements separate from global references and unknowns.</p>
      </div>
      <div className="month-control"><label htmlFor={compact ? 'climate-month-small' : 'climate-month'}>Earth NASA POWER period</label>
        <select id={compact ? 'climate-month-small' : 'climate-month'} value={month} onChange={event => setMonth(event.target.value)}>
          {MONTHS.map(([id, name]) => <option key={id} value={id}>{name}</option>)}
        </select>
      </div>
    </header>
    {!compact && <div className="parameter-filters" role="group" aria-label="Filter data by world">
      {['all', ...WORLD_ORDER].map(w => <button type="button" key={w} onClick={() => setFocus(w)} className={focus === w ? 'active' : ''}>{w === 'all' ? 'All 3 worlds' : w[0].toUpperCase() + w.slice(1)}</button>)}
    </div>}
    <div className={`parameter-world-grid ${worlds.length === 1 ? 'single' : ''}`}>
      {worlds.map(world => <DataWorld key={world} world={world} siteId={sites[world]} onSiteChange={onSiteChange}
        power={power} month={month} compact={compact} />)}
    </div>
    {compact ? <div className="data-quick-footer">
      <span>Moon figures use NASA planetary reference data, not a lunar weather station.</span>
      {onOpenData && <button className="subtle-button" onClick={onOpenData}>See all 12 parameters</button>}
    </div> : <div className="parameter-method">
      <p><strong>Data integrity:</strong> Earth temperature, pressure, humidity, wind and surface solar energy come from NASA POWER gridded climatology when the API is available. Mars/Moon physical constants describe each body as a whole. No missing site readings are fabricated. Month selection affects Earth modeled climate only.</p>
      <p>{power.status === 'loading' ? 'NASA POWER data is loading.' : power.status === 'error' ? 'NASA POWER is unavailable; corresponding Earth values are intentionally blank.' : 'NASA POWER Earth climatology loaded.'}</p>
      <div className="parameter-sources">
        <a href={power.url || SOURCE_URLS.nasaPower} target="_blank" rel="noreferrer">Earth POWER request</a>
        <a href={SOURCE_URLS.earth} target="_blank" rel="noreferrer">Earth fact sheet</a>
        <a href={SOURCE_URLS.mars} target="_blank" rel="noreferrer">Mars fact sheet</a>
        <a href={SOURCE_URLS.moon} target="_blank" rel="noreferrer">Moon fact sheet</a>
        <a href={SOURCE_URLS.lunarCoords} target="_blank" rel="noreferrer">Apollo coordinates</a>
      </div>
    </div>}
  </section>;
}
