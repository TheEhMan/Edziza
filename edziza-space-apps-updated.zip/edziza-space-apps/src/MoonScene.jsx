import React, { useEffect, useRef, useState } from 'react';
import { Canvas, useThree } from '@react-three/fiber';
import { Html, OrbitControls } from '@react-three/drei';
import * as THREE from 'three';
import { WORLD_SITES, formatCoord } from './siteData.js';
import './moon.css';

// NASA SVS CGI Moon Kit: 2025 LROC WAC-derived 2k color map.
// https://svs.gsfc.nasa.gov/4720/ (visualization texture, NOT a scientific elevation product).
const TEXTURE_URL = 'https://svs.gsfc.nasa.gov/vis/a000000/a004700/a004720/lroc_color_2k.jpg';
const RADIUS = 3;
const LOCATIONS = Object.values(WORLD_SITES.moon);

function pointOnGlobe(lat, lon, radius = RADIUS) {
  const a = lat * Math.PI / 180;
  const b = lon * Math.PI / 180;
  // NASA texture is equirectangular, 0 E in the middle; Three.js sphere UV starts at -180 E.
  return new THREE.Vector3(radius * Math.cos(a) * Math.cos(b), radius * Math.sin(a), -radius * Math.cos(a) * Math.sin(b));
}

function MoonCamera({ site, controlsRef }) {
  const { camera } = useThree();
  useEffect(() => {
    const location = WORLD_SITES.moon[site] || WORLD_SITES.moon.apollo11;
    camera.position.copy(pointOnGlobe(location.lat, location.lon, 9.4));
    camera.lookAt(0, 0, 0);
    camera.updateProjectionMatrix();
    if (controlsRef.current) {
      controlsRef.current.target.set(0, 0, 0);
      controlsRef.current.update();
    }
  }, [camera, site, controlsRef]);
  return null;
}

function MoonGlobe({ site, texture }) {
  return <>
    <mesh rotation={[0, 0, 0]}>
      <sphereGeometry args={[RADIUS, 96, 64]} />
      <meshStandardMaterial map={texture || null} color={texture ? '#ffffff' : '#9fa3a7'} roughness={1} metalness={0} />
    </mesh>
    {LOCATIONS.map(location => {
      const selected = site === location.id;
      const pos = pointOnGlobe(location.lat, location.lon, RADIUS + 0.045);
      return <group key={location.id}>
        <mesh position={pos.toArray()}>
          <sphereGeometry args={[selected ? 0.073 : 0.046, 12, 12]} />
          <meshBasicMaterial color={selected ? '#b1ffe0' : '#ffcc9e'} depthTest />
        </mesh>
        <Html position={pointOnGlobe(location.lat, location.lon, RADIUS + 0.12).toArray()}
          center occlude distanceFactor={8} style={{ pointerEvents: 'none' }}>
          <div className={`moon-marker ${selected ? 'is-selected' : ''}`}>{location.label}</div>
        </Html>
      </group>;
    })}
  </>;
}

export default function MoonScene({ site = 'apollo11', onSiteChange }) {
  const controlsRef = useRef(null);
  const [texture, setTexture] = useState(null);
  const [textureError, setTextureError] = useState(false);

  useEffect(() => {
    let cancelled = false;
    let loadedTexture = null;
    const loader = new THREE.TextureLoader();
    loader.setCrossOrigin('anonymous');
    loader.load(TEXTURE_URL, (result) => {
      result.colorSpace = THREE.SRGBColorSpace;
      result.anisotropy = 8;
      if (cancelled) result.dispose();
      else { loadedTexture = result; setTexture(result); }
    }, undefined, () => { if (!cancelled) setTextureError(true); });
    return () => {
      cancelled = true;
      loadedTexture?.dispose();
    };
  }, []);

  const selected = WORLD_SITES.moon[site] || WORLD_SITES.moon.apollo11;
  return <div className="moon-scene">
    {!textureError ? <Canvas camera={{ position: [9, 1.5, 1], fov: 45, near: 0.1, far: 100 }} dpr={[1, 1.7]}>
      <color attach="background" args={['#0a1019']} />
      <ambientLight intensity={1.35} />
      <directionalLight position={[6, 4, 10]} intensity={1.8} color="#fff4e0" />
      <MoonGlobe site={site} texture={texture} />
      <OrbitControls ref={controlsRef} enableDamping dampingFactor={0.07}
        minDistance={4.3} maxDistance={18} enablePan={false} minPolarAngle={0.01} maxPolarAngle={Math.PI - 0.01} />
      <MoonCamera site={site} controlsRef={controlsRef} />
    </Canvas> : <div className="moon-atlas" aria-label="NASA LRO lunar equirectangular map">
      <img src={TEXTURE_URL} alt="NASA LRO lunar global imagery map" />
      {LOCATIONS.map(location => <button key={location.id} type="button"
        className={`moon-atlas-pin ${site === location.id ? 'selected' : ''}`}
        title={location.label} aria-label={`Go to ${location.label}`}
        style={{ left: `${(location.lon + 180) / 360 * 100}%`, top: `${(90 - location.lat) / 180 * 100}%` }}
        onClick={() => onSiteChange?.(location.id)} />)}
      <div className="moon-atlas-note">2D NASA map fallback · 3D texture access unavailable</div>
    </div>}
    <div className="moon-hud">{texture ? 'NASA LRO · WAC COLOR MOSAIC' : textureError ? 'NASA LRO · 2D FALLBACK' : 'LOADING NASA LRO IMAGERY'}</div>
    <div className="moon-hint">Drag to rotate · Scroll to zoom</div>
    <div className="moon-location-toolbar" aria-label="Moon locations">
      {LOCATIONS.map(location => <button type="button" key={location.id} className={site === location.id ? 'selected' : ''}
        onClick={() => onSiteChange?.(location.id)}>{location.id === 'apollo11' ? 'Apollo 11' : location.id === 'shackleton' ? 'Shackleton' : 'Aristarchus'}</button>)}
    </div>
    <div className="moon-source">
      <strong>{formatCoord(selected.lat, 'lat')} · {formatCoord(selected.lon, 'lon')}</strong>
      <span>NASA SVS LRO texture · spherical globe, no measured local relief</span>
      <a href="https://svs.gsfc.nasa.gov/4720/" target="_blank" rel="noreferrer">Image credit</a>
    </div>
  </div>;
}
