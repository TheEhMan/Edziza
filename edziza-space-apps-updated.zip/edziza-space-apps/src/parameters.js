// Exactly twelve shared fields per selected location; values never masquerade as local
// measurements when they are planetary references or missing for that location.
export const PARAMETERS = [
  { id: 'latitude', label: 'Latitude', detail: 'Selected study location, not an area-wide average' },
  { id: 'longitude', label: 'Longitude', detail: 'Earth WGS84; planetary coordinates use east-positive longitude' },
  { id: 'temperature', label: 'Temperature', detail: '2 m air temperature on Earth; planet-wide Mars reference, no Moon site weather' },
  { id: 'pressure', label: 'Surface pressure', detail: 'Modeled on Earth; global-scale reference on Mars and Moon' },
  { id: 'humidity', label: 'Relative humidity', detail: 'Earth climatology only; not a known local Mars/Moon reading' },
  { id: 'wind', label: 'Wind speed', detail: 'Earth 10 m wind speed; no local Mars estimate, not applicable to Moon' },
  { id: 'surfaceSolar', label: 'Surface solar energy', detail: 'NASA POWER Earth average, kWh/m²/day; not derived for Mars or Moon' },
  { id: 'gravity', label: 'Surface gravity', detail: 'Planetary mean reference in m/s², not a site survey' },
  { id: 'solarDay', label: 'Solar day length', detail: 'Average sunrise-to-sunrise period, not actual local daylight hours' },
  { id: 'orbitalSolar', label: 'Orbital solar irradiance', detail: 'Mean incoming sunlight outside the atmosphere, NOT surface insolation' },
  { id: 'terrain', label: 'Terrain / geology', detail: 'Qualitative site description; not determined from the photo alone' },
  { id: 'ice', label: 'Water / ice evidence', detail: 'Published regional evidence or an explicit not-assessed label; not a resource estimate' }
];

